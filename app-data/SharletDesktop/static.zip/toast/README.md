# Toasty.js
A minimal JavaScript notification plugin that provides a simple way to display customizable toast messages on the web page with CSS3 transition effects.

`npm i egalink-toasty.js`

Read full documentation in: [Toasty.js](http://jakim.me/Toasty.js/)
